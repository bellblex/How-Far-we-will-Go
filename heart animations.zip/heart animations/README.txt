You found my note!
Hello!
Thanks for downloading my asset pack, I hope you like it!

As a small creator, I cannot understate how much your 
support means to me. If you have any requests/suggestions
for other animations I could add to this pack (or ideas 
for future packs), please let me know on itch.io or my 
YouTube channel.

And send me links to your projects if you've used my art!
I'd love to check it out

Happy developing!

✧⁺⸜(●′▾‵●)⸝⁺✧





p.s. I included an extra animation for funsies :)